Designated Submitter: Zuhao Yang 1558365
Changxin Zhan 1539600
Ziyi Ye 1553475

Team Name: Sleeping Teddy Bear